#!/usr/bin/env python3

"""
Faculty Discovery

Purpose:
    Retrieve the faculty/researcher records ufor the conifgured dapartment

Source:
    configured faculty source, typically: UTRGV Digital Measures Faculty Directory API

This script is READ-ONLY with respect to PostgreSQL.
It does not create or modify database records.

Output:
    <conifgured department output directory> / faculty.json
"""

import json
import urllib.request
from pathlib import Path
import yaml
import argparse

# ------------------------------------------------------------
# Configuration
# ------------------------------------------------------------

def load_config(config_file):
    """
    Load department configuration from YAML.
    """

    with open(config_file, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    return config

# ------------------------------------------------------------
# Download the official faculty directory data
# ------------------------------------------------------------

def fetch_faculty_data(api_url):
    """
    Download the faculty directory data from UTRGV.

    The API returns JSON encoded inside a JSON string,
    so we may need to decode it twice.
    """

    request = urllib.request.Request(
        api_url,
        headers={
            "User-Agent": "Mozilla/5.0",
            "Accept": "application/json",
        },
    )

    print("Downloading faculty directory...")

    with urllib.request.urlopen(request, timeout=30) as response:
        raw_data = response.read().decode(
            "utf-8",
            errors="replace"
        )

    # First JSON decoding.
    data = json.loads(raw_data)

    # The API currently returns a JSON string containing JSON.
    if isinstance(data, str):
        data = json.loads(data)

    return data


# ------------------------------------------------------------
# Extract a value from the IndexEntry records
# ------------------------------------------------------------

def get_index_value(entries, index_key):
    """
    Find an index entry such as DEPARTMENT or RANK.
    """

    if not isinstance(entries, list):
        return ""

    for entry in entries:

        if not isinstance(entry, dict):
            continue

        if entry.get("@indexKey") == index_key:
            return entry.get("@text", "") or ""

    return ""


# ------------------------------------------------------------
# Build a person's full name
# ------------------------------------------------------------

def build_name(pci):
    """
    Build the faculty member's name from the PCI fields.
    """

    if not isinstance(pci, dict):
        return ""

    parts = [
        pci.get("PREFIX"),
        pci.get("FNAME"),
        pci.get("MNAME"),
        pci.get("LNAME"),
        pci.get("SUFFIX"),
    ]

    # Remove empty values.
    parts = [
        str(part).strip()
        for part in parts
        if part
    ]

    return " ".join(parts)


# ------------------------------------------------------------
# Extract MAIE faculty
# ------------------------------------------------------------

def extract_faculty(data, target_department):
    """
    Extract everyone belonging to the specified department.

    We intentionally keep all records returned for the
    department, including lecturers and professors of practice.

    The official Faculty Directory is our authority for
    who belongs in this initial roster.
    """

    records = data.get("Data", {}).get("Record", [])

    if not isinstance(records, list):
        raise ValueError(
            "Unexpected API format: Data.Record is not a list."
        )

    faculty = []

    for record in records:

        if not isinstance(record, dict):
            continue

        entries = record.get("dmd:IndexEntry", [])

        department = get_index_value(
            entries,
            "DEPARTMENT"
        )

        # Exact department match.
        if department != target_department:
            continue

        pci = record.get("PCI", {})

        name = build_name(pci)

        if not name:
            continue

        rank = get_index_value(
            entries,
            "RANK"
        )

        faculty_member = {
            "name": name,
            "rank": rank,
            "department": department,
            "username": record.get("@username"),
            "user_id": record.get("@userId"),
        }

        faculty.append(faculty_member)

    # Keep the output deterministic.
    faculty.sort(
        key=lambda person: person["name"].lower()
    )

    return faculty


# ------------------------------------------------------------
# Save the roster
# ------------------------------------------------------------

def save_faculty(faculty, output_file):    
    """
    Save the faculty roster as formatted JSON.
    """

    output_file.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    with open(
        output_file,
        "w",
        encoding="utf-8"
    ) as file:

        json.dump(
            faculty,
            file,
            indent=2,
            ensure_ascii=False
        )

        file.write("\n")

def parse_args():

    parser = argparse.ArgumentParser(
        description="Discover faculty from UTRGV Digital Measures"
    )

    parser.add_argument(
        "--config",
        required=True,
        help="Path to department config.yaml"
    )

    return parser.parse_args()
# ------------------------------------------------------------
# Main
# ------------------------------------------------------------

def main():
    args = parse_args()
    
    config = load_config(args.config)
    
    target_department = config["department_name"]

    faculty_source = config["sources"]["faculty"]

    if faculty_source["type"] != "digital_measures":
        raise ValueError(
            "discover_faculty.py currently supports only "
            "the 'digital_measures' faculty source."
        )
    
    api_url = faculty_source["api_url"]
    
    output_directory = Path(
        config["output_directory"]
    )
    
    output_file = (
        output_directory / "faculty.json"
    )

    print("=" * 60)
    print("UTRGV FACULTY DISCOVERY")
    print("=" * 60)
    print()

    print("Department:")
    print(target_department)
    print()

    print("Source:")
    print(api_url)
    print()

    # Download API data.
    data = fetch_faculty_data(api_url)

    # Extract faculty.
    faculty = extract_faculty(
        data,
        target_department
    )

    print()
    print("=" * 60)
    print(" FACULTY FOUND")
    print("=" * 60)
    print()

    for number, person in enumerate(faculty, start=1):
        print(
            f"{number:2}. "
            f"{person['name']}"
        )

        print(
            f"    Rank:     {person['rank']}"
        )

        print(
            f"    Username: {person['username']}"
        )

        print()

    # Save JSON.
    save_faculty(faculty, output_file)
    

    print("=" * 60)
    print(f"TOTAL FACULTY: {len(faculty)}")
    print("=" * 60)
    print()

    print("Saved to:")
    print(output_file)
    print()

    print("READ-ONLY:")
    print("No PostgreSQL records were created or modified.")


if __name__ == "__main__":
    main()