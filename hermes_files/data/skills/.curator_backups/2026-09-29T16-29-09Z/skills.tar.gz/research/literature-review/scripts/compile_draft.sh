#!/bin/sh
# Compile writing/drafts/main.tex to PDF with Tectonic.
# Run from the project root:  sh scripts/compile_draft.sh
# - points \bibliography at the references.bib next to main.tex (written by build_bib.py)
# - adds \usepackage{url} after \documentclass if missing
set -e
SKILL_DIR="/opt/data/skills/research/literature-review"
cd writing/drafts
[ -f main.tex ] || { echo "No writing/drafts/main.tex"; exit 1; }
[ -f references.bib ] || { echo "No writing/drafts/references.bib. Run build_bib.py first."; exit 1; }

sed -i 's#\\bibliography{[^}]*}#\\bibliography{references}#' main.tex
if ! grep -q 'usepackage{url}' main.tex; then
  sed -i '/\\documentclass/a \\\\usepackage{url}' main.tex
fi

"${TECTONIC:-$SKILL_DIR/bin/tectonic}" main.tex
echo "PDF written: writing/drafts/main.pdf ($(du -k main.pdf | cut -f1) KB)"