"""Build bibliography/references.bib from the draft's \\cite keys and the manifest.

Run from the project root:
    .venv/bin/python scripts/build_bib.py

Keys are the note names made by summarize_papers.py (e.g. Caplin_2025,
Almog_2024_2). Each key is matched to its manifest row using the same naming
rule, so author, year, title, and URL come from the manifest, never from memory.

Writes bibliography/references.bib and a copy at writing/drafts/references.bib.
Prints any \\cite key with no matching paper; exits with code 1 if there are any.
"""
import csv
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from summarize_papers import note_name  # noqa: E402

LATEX_SPECIAL = {"&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_"}


def esc(text):
    return "".join(LATEX_SPECIAL.get(c, c) for c in text)


def main():
    root = Path.cwd()
    manifest = root / "documents" / "manifests" / "manifest.tsv"
    draft = root / "writing" / "drafts" / "main.tex"
    for p in (manifest, draft):
        if not p.exists():
            sys.exit(f"Missing {p}. Run from the project root after the draft exists.")

    papers, used = {}, set()
    for row in csv.reader(open(manifest, encoding="utf-8"), delimiter="\t"):
        if len(row) >= 5:
            key = note_name(row[1], row[2], used)[:-3]
            papers[key] = {"author": row[1], "year": row[2], "title": row[3], "url": row[4]}

    tex = draft.read_text(encoding="utf-8")
    cited = []
    for group in re.findall(r"\\cite[a-z]*\{([^}]*)\}", tex):
        for k in group.split(","):
            k = k.strip()
            if k and k not in cited:
                cited.append(k)

    entries, missing = [], []
    for k in cited:
        p = papers.get(k)
        if not p:
            missing.append(k)
            continue
        entries.append(
            f"@misc{{{k},\n"
            f"  author = {{{esc(p['author'])} and others}},\n"
            f"  title = {{{{{esc(p['title'])}}}}},\n"
            f"  year = {{{p['year']}}},\n"
            f"  url = {{{p['url']}}}\n"
            f"}}\n")

    bib = "\n".join(entries)
    for out in (root / "bibliography" / "references.bib", root / "writing" / "drafts" / "references.bib"):
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(bib, encoding="utf-8")

    print(f"Cited keys: {len(cited)}   Written: {len(entries)}   Missing: {len(missing)}")
    for k in missing:
        print(f"MISSING  {k}  (no paper in the manifest has this key)")
    unused = [k for k in papers if k not in cited]
    if unused:
        print("Not cited: " + ", ".join(unused))
    sys.exit(1 if missing else 0)


if __name__ == "__main__":
    main()