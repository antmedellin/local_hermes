"""Write one LightRAG summary note per paper in the manifest.

Run from the project root:
    .venv/bin/python scripts/summarize_papers.py

For each row of documents/manifests/manifest.tsv, asks LightRAG (written-answer
mode) to summarize that paper and saves it to notes/literature/<Author>_<Year>.md.
Existing notes are skipped, so it is safe to rerun after a failure.
Also writes notes/literature/index.md listing every note.
"""
import csv
import re
import sys
import time
import unicodedata
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from document_rag_search import search, format_result  # noqa: E402

QUESTION = ("Summarize the paper titled \"{title}\" by {author} ({year}). "
            "Cover its research question, method or data, main findings, "
            "and its main contribution to the literature. Use only this paper.")


def note_name(author, year, used):
    ascii_author = unicodedata.normalize("NFKD", author).encode("ascii", "ignore").decode()
    last = re.sub(r"[^A-Za-z]", "", ascii_author.split()[-1]) if ascii_author.strip() else "Unknown"
    base = f"{last}_{year}"
    name, n = base, 2
    while name in used:
        name, n = f"{base}_{n}", n + 1
    used.add(name)
    return name + ".md"


def main():
    root = Path.cwd()
    manifest = root / "documents" / "manifests" / "manifest.tsv"
    if not manifest.exists():
        sys.exit(f"No manifest at {manifest}. Run from the project root.")
    out = root / "notes" / "literature"
    out.mkdir(parents=True, exist_ok=True)

    rows = [r for r in csv.reader(open(manifest, encoding="utf-8"), delimiter="\t") if len(r) >= 4]
    used, index, done, skipped, failed = set(), [], 0, 0, 0

    for i, row in enumerate(rows, 1):
        author, year, title = row[1], row[2], row[3]
        name = note_name(author, year, used)
        path = out / name
        index.append(f"- [{name}]({name}): {author} ({year}), {title}")
        if path.exists() and path.stat().st_size > 0:
            print(f"[{i}/{len(rows)}] exists  {name}")
            skipped += 1
            continue
        print(f"[{i}/{len(rows)}] asking  {name} ...", flush=True)
        try:
            result = search(QUESTION.format(title=title, author=author, year=year), answer=True)
            text = format_result(result)
            path.write_text(f"# {author} ({year}). {title}\n\n{text}\n", encoding="utf-8")
            print(f"            saved   {name}")
            done += 1
        except Exception as e:
            print(f"            FAILED  {name}: {e}")
            failed += 1
        time.sleep(1)

    (out / "index.md").write_text("# Paper notes\n\n" + "\n".join(index) + "\n", encoding="utf-8")
    print(f"\nWritten: {done}   Already had: {skipped}   Failed: {failed}")
    print(f"Notes in {out}")


if __name__ == "__main__":
    main()
