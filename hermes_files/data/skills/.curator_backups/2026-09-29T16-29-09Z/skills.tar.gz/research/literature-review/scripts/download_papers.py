"""Download the PDFs listed in documents/manifests/manifest.tsv.

Run from the project root:
    .venv/bin/python scripts/download_papers.py

For each paper it tries several sources, in order, until one returns a real PDF:
  1. Known mirrors / direct-PDF rewrites of the manifest URL
     (osti.gov/biblio -> servlets/purl, www.mdpi.com -> mdpi-res.com)
  2. The manifest URL itself
  3. Open-access copies found by DOI: Unpaywall (if CONTACT_EMAIL is set),
     Crossref PDF links, Semantic Scholar

Papers that still fail (paywalls, Cloudflare "Just a moment" pages) are written to
documents/manifests/manual_downloads.tsv with the exact file name to save them as.
Drop those PDFs into documents/renamed/ by hand and rerun; existing files are skipped.
"""
import csv
import difflib
import re
import sys
from pathlib import Path

import requests

# Optional: your email enables Unpaywall lookups (free, no signup, just identifies you).
CONTACT_EMAIL = ""

HEADERS = {
    "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                   "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"),
    "Accept": "application/pdf,*/*;q=0.8",
}
API_HEADERS = {"User-Agent": "literature-review-downloader (mailto:%s)" % (CONTACT_EMAIL or "none")}

OSTI_BIBLIO = re.compile(r"^https?://(www\.)?osti\.gov/biblio/(\d+)")
MDPI_PAGE = re.compile(r"^https?://(www\.)?mdpi\.com/(\d{4}-\d{3}[\dX])/(\d+)/(\d+)/(\d+)")
MDPI_SLUG_OVERRIDES = {
    "applied sciences": "applsci",
    "international journal of molecular sciences": "ijms",
    "international journal of environmental research and public health": "ijerph",
    "remote sensing": "remotesensing",
}
_mdpi_slugs = {}


def similar(a, b):
    norm = lambda s: " ".join(re.sub(r"[^a-z0-9 ]", " ", s.lower()).split())
    return difflib.SequenceMatcher(None, norm(a), norm(b)).ratio()


def api_json(url, **params):
    try:
        r = requests.get(url, params=params, headers=API_HEADERS, timeout=30)
        return r.json() if r.status_code == 200 else None
    except Exception:
        return None


def mdpi_slug(issn):
    if issn not in _mdpi_slugs:
        data = api_json(f"https://api.crossref.org/journals/{issn}")
        title = ((data or {}).get("message") or {}).get("title", "")
        t = title.lower().strip()
        _mdpi_slugs[issn] = MDPI_SLUG_OVERRIDES.get(t, re.sub(r"[^a-z0-9]", "", t))
    return _mdpi_slugs[issn]


def rewrites(url):
    """Known direct-PDF forms of a URL. Returns a list (may be empty)."""
    out = []
    m = OSTI_BIBLIO.match(url)
    if m:
        out.append(f"https://www.osti.gov/servlets/purl/{m.group(2)}")
    m = MDPI_PAGE.match(url)
    if m:
        issn, vol, _issue, art = m.group(2), m.group(3), m.group(4), m.group(5)
        slug = mdpi_slug(issn)
        if slug:
            code = f"{slug}-{int(vol):02d}-{int(art):05d}"
            out.append(f"https://mdpi-res.com/d_attachment/{slug}/{code}/article_deploy/{code}.pdf")
    return out


def find_doi(title):
    data = api_json("https://api.crossref.org/works", **{"query.title": title, "rows": 3, "select": "DOI,title"})
    for it in ((data or {}).get("message") or {}).get("items", []):
        if it.get("title") and similar(it["title"][0], title) >= 0.9:
            return it["DOI"]
    return None


def doi_sources(doi):
    urls = []
    if CONTACT_EMAIL:
        d = api_json(f"https://api.unpaywall.org/v2/{doi}", email=CONTACT_EMAIL) or {}
        urls += [l["url_for_pdf"] for l in d.get("oa_locations") or [] if l.get("url_for_pdf")]
    d = api_json(f"https://api.crossref.org/works/{doi}") or {}
    urls += [l["URL"] for l in (d.get("message") or {}).get("link", [])
             if l.get("content-type") == "application/pdf"]
    d = api_json(f"https://api.semanticscholar.org/graph/v1/paper/DOI:{doi}", fields="openAccessPdf") or {}
    if (d.get("openAccessPdf") or {}).get("url"):
        urls.append(d["openAccessPdf"]["url"])
    return urls


def fetch_pdf(url):
    r = requests.get(url, timeout=60, headers=HEADERS, allow_redirects=True)
    if r.status_code != 200:
        return None, f"HTTP {r.status_code}"
    if not r.content.startswith(b"%PDF"):
        return None, "not a PDF (web page or bot check)"
    return r.content, None


def unique(seq):
    seen, out = set(), []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


def main():
    root = Path.cwd()
    man_dir = root / "documents" / "manifests"
    manifest = man_dir / "manifest.tsv"
    if not manifest.exists():
        sys.exit(f"No manifest at {manifest}. Run from the project root after discover_papers.py.")

    ok = skipped = failed = 0
    manual = []
    with open(manifest, newline="", encoding="utf-8") as f:
        rows = [r for r in csv.reader(f, delimiter="\t") if len(r) >= 5]

    for row in rows:
        target, title, url = root / row[0], row[3], row[4]
        if target.exists() and target.stat().st_size > 0:
            print(f"exists  {target.name}")
            skipped += 1
            continue
        target.parent.mkdir(parents=True, exist_ok=True)

        tried, doi = [], None
        candidates = unique(rewrites(url) + [url])
        saved = False
        while candidates:
            u = candidates.pop(0)
            content, err = fetch_pdf(u) if u else (None, "no url")
            tried.append(f"{u} ({err or 'ok'})")
            if content:
                target.write_bytes(content)
                print(f"saved   {target.name}  <- {u}")
                saved = True
                break
            if not candidates and doi is None:
                doi = find_doi(title) or ""
                if doi:
                    more = [x for s in doi_sources(doi) for x in rewrites(s) + [s]]
                    candidates = [x for x in unique(more) if x not in {t.split(' (')[0] for t in tried}]

        if saved:
            ok += 1
        else:
            failed += 1
            link = f"https://doi.org/{doi}" if doi else url
            manual.append(f"{target.name}\t{title}\t{link}\n")
            print(f"FAILED  {title}")
            for t in tried:
                print(f"          tried {t}")

    manual_file = man_dir / "manual_downloads.tsv"
    if manual:
        manual_file.write_text("".join(manual), encoding="utf-8")
    elif manual_file.exists():
        manual_file.unlink()

    print(f"\nDownloaded: {ok}   Already had: {skipped}   Failed: {failed}")
    if manual:
        print(f"Get the failed ones by hand: see {manual_file.relative_to(root)}")
        print("Save each PDF into documents/renamed/ under the exact name in column 1, then rerun.")


if __name__ == "__main__":
    main()
