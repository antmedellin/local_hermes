"""Discover papers for a literature review from a seed arXiv paper or PDF.

Run from the project root:
    .venv/bin/python scripts/discover_papers.py --seed 2502.00195
    .venv/bin/python scripts/discover_papers.py --seed PA_007.pdf

Reference list source, in order:
  1. documents/manifests/seed_references.txt if it exists (lines: year|title)
  2. otherwise, if --seed is an arXiv ID, the seed's arXiv HTML bibliography,
     saved to that file

When --seed is an arXiv ID, the seed paper's own metadata is looked up and
added to the manifest as well. When --seed is a local file (a PDF you
supplied), only its references are discovered; the seed document itself is
not looked up or added, since a review of its references doesn't need its
own metadata in the corpus.

Each reference is looked up in OpenAlex, then Semantic Scholar, then arXiv,
stopping at the first source that has a free PDF.

Optional: a Semantic Scholar API key (free) raises its rate limit. Put it in
the S2_API_KEY environment variable or in the file
/opt/data/skills/research/literature-review/.s2_api_key

Outputs in documents/manifests/:
  manifest.tsv        papers with a free PDF (path, first author, year, title, url)
  missing_pdfs.tsv    paywalled or not found
"""
import argparse
import os
import difflib
import re
import sys
import time
from pathlib import Path

import arxiv
import requests
from lxml import html

API = "https://api.openalex.org/works"
MATCH = 0.85
ARXIV = arxiv.Client(page_size=5, delay_seconds=3, num_retries=1)
ARXIV_OK = True  # switched off for the rest of the run after the first arXiv refusal
ARXIV_ID_RE = re.compile(r"^\d{4}\.\d{4,5}(v\d+)?$")

S2_MATCH = "https://api.semanticscholar.org/graph/v1/paper/search/match"
S2_KEY_FILE = Path("/opt/data/skills/research/literature-review/.s2_api_key")
S2_OK = True  # switched off for the rest of the run if Semantic Scholar keeps refusing


def s2_key():
    key = os.environ.get("S2_API_KEY", "").strip()
    if not key and S2_KEY_FILE.exists():
        key = S2_KEY_FILE.read_text().strip()
    return key


def is_arxiv_id(seed):
    return bool(ARXIV_ID_RE.match(seed))


def clean(t):
    return re.sub(r"[^A-Za-z0-9 \-]", " ", t).strip()


def similar(a, b):
    a = " ".join(clean(a).lower().split())
    b = " ".join(clean(b).lower().split())
    return difflib.SequenceMatcher(None, a, b).ratio()


def safe_name(title):
    return "".join(c for c in title if c.isalnum() or c in "_-")


def seed_info(arxiv_id):
    res = list(ARXIV.results(arxiv.Search(id_list=[arxiv_id])))
    if not res:
        sys.exit(f"Seed arXiv ID not found: {arxiv_id}")
    r = res[0]
    first = r.authors[0].name if r.authors else "Unknown"
    return r.title, r.published.year, first, f"https://arxiv.org/pdf/{arxiv_id}"


def refs_from_arxiv_html(arxiv_id):
    r = requests.get(f"https://arxiv.org/html/{arxiv_id}", timeout=60)
    if r.status_code != 200:
        return []
    doc = html.fromstring(r.content)
    refs = []
    for li in doc.xpath('//li[contains(@class,"ltx_bibitem")]'):
        text = " ".join(li.text_content().split())
        m = re.search(r"[\u201c\"](.+?)[\u201d\"]", text)
        y = re.search(r"\b(1[5-9]\d{2}|20\d{2})\b", text)
        if m and y:
            refs.append((int(y.group(1)), m.group(1).strip(" ,.")))
    return refs


def load_refs(refs_file, seed):
    if refs_file.exists():
        print(f"Using reference list: {refs_file}")
        out = []
        for line in refs_file.read_text(encoding="utf-8").splitlines():
            if "|" in line:
                y, t = line.split("|", 1)
                out.append((int(y), t.strip()))
        return out
    if not is_arxiv_id(seed):
        sys.exit(f"{refs_file} does not exist and --seed {seed!r} is not an arXiv ID. "
                  "Create the file by hand (one 'year|title' per line) and rerun.")
    print("Reading references from the seed's arXiv HTML page...")
    refs = refs_from_arxiv_html(seed)
    if not refs:
        sys.exit("No references found automatically. Create "
                 f"{refs_file} by hand (one 'year|title' per line) and rerun.")
    refs_file.write_text("".join(f"{y}|{t}\n" for y, t in refs), encoding="utf-8")
    print(f"Saved {len(refs)} references to {refs_file}")
    return refs


def get(params):
    for attempt in range(6):
        r = requests.get(API, params=params, timeout=30)
        if r.status_code == 429:
            wait = 10 * (attempt + 1)
            print(f"  OpenAlex busy, waiting {wait}s...")
            time.sleep(wait)
            continue
        r.raise_for_status()
        return r.json()
    sys.exit("OpenAlex kept rate limiting. Wait a few minutes and rerun.")


def openalex(year, title):
    data = get({"filter": f"title.search:{clean(title)}",
                "select": "title,doi,publication_year,authorships,best_oa_location,locations",
                "per_page": 5})
    for w in data.get("results", []):
        y = w.get("publication_year") or 0
        if abs(y - year) > 2 or similar(w.get("title") or "", title) < MATCH:
            continue
        urls = []
        best = w.get("best_oa_location") or {}
        if best.get("pdf_url"):
            urls.append(best["pdf_url"])
        for loc in w.get("locations") or []:
            if loc and loc.get("pdf_url"):
                urls.append(loc["pdf_url"])
        auth = w.get("authorships") or []
        first = auth[0]["author"]["display_name"] if auth else "Unknown"
        doi = (w.get("doi") or "").replace("https://doi.org/", "")
        return w["title"], y, first, (urls[0] if urls else ""), doi
    return None


S2_PAPER = "https://api.semanticscholar.org/graph/v1/paper/DOI:{}"


def s2_get(url, params):
    """GET with retries on 429. Returns parsed JSON, None on no match, or False if S2 is refusing."""
    headers = {"x-api-key": s2_key()} if s2_key() else {}
    for attempt in range(3):
        try:
            r = requests.get(url, params=params, headers=headers, timeout=30)
        except requests.RequestException as e:
            print(f"  Semantic Scholar error: {e}")
            return None
        if r.status_code == 429:
            wait = 5 * (attempt + 1)
            print(f"  Semantic Scholar busy, waiting {wait}s...")
            time.sleep(wait)
            continue
        if r.status_code == 404:
            return None
        if r.status_code != 200:
            print(f"  Semantic Scholar error: HTTP {r.status_code}")
            return None
        return r.json()
    return False


def s2_by_doi(doi):
    """Free PDF link for a DOI from Semantic Scholar (works without a key). Returns url or ''."""
    global S2_OK
    if not S2_OK or not doi:
        return ""
    data = s2_get(S2_PAPER.format(doi), {"fields": "openAccessPdf"})
    if data is False:
        S2_OK = False
        print("  Semantic Scholar kept rate limiting. Skipping it for the rest of this run.")
        return ""
    return ((data or {}).get("openAccessPdf") or {}).get("url") or ""


def s2_lookup(year, title):
    """Title search on Semantic Scholar (reliable with an API key; often busy without).
    Returns (title, year, first_author, pdf_url) or None."""
    global S2_OK
    if not S2_OK:
        return None
    data = s2_get(S2_MATCH, {"query": clean(title), "fields": "title,year,authors,openAccessPdf"})
    if data is False:
        S2_OK = False
        print("  Semantic Scholar kept rate limiting. Skipping it for the rest of this run.")
        return None
    hit = ((data or {}).get("data") or [None])[0]
    if not hit:
        return None
    y = hit.get("year") or 0
    if similar(hit.get("title") or "", title) < MATCH or (y and abs(y - year) > 2):
        return None
    auth = hit.get("authors") or []
    first = auth[0].get("name", "Unknown") if auth else "Unknown"
    url = (hit.get("openAccessPdf") or {}).get("url") or ""
    return hit["title"], y or year, first, url


def arxiv_lookup(title):
    global ARXIV_OK
    if not ARXIV_OK:
        return None
    try:
        for r in ARXIV.results(arxiv.Search(query=f'ti:"{clean(title)}"', max_results=3)):
            if similar(r.title, title) >= MATCH:
                first = r.authors[0].name if r.authors else "Unknown"
                return r.title, r.published.year, first, r.pdf_url
    except Exception as e:
        ARXIV_OK = False
        print(f"  arXiv refused ({e}). Skipping arXiv for the rest of this run to avoid a longer block.")
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seed", required=True,
                    help="seed arXiv ID (e.g. 2502.00195) or a local PDF file name")
    args = ap.parse_args()

    man = Path.cwd() / "documents" / "manifests"
    if not man.parent.exists():
        sys.exit("Run this from the project root (the folder with documents/).")
    man.mkdir(parents=True, exist_ok=True)

    found = []
    if is_arxiv_id(args.seed):
        s_title, s_year, s_first, s_url = seed_info(args.seed)
        print(f"Seed: {s_title} ({s_first}, {s_year})")
        found.append((f"documents/renamed/{safe_name(s_title)}.pdf", s_first, s_year, s_title, s_url))
    else:
        print(f"Seed is a local document ({args.seed}); its own metadata is not looked up.")
        print("Discovery proceeds using its reference list only.")

    missing, notfound = [], []

    for year, title in load_refs(man / "seed_references.txt", args.seed):
        res = openalex(year, title)
        time.sleep(2)
        source = "OpenAlex"
        if res and not res[3] and len(res) > 4 and res[4]:
            pdf = s2_by_doi(res[4])
            time.sleep(1.1)
            if pdf:
                res, source = res[:3] + (pdf,), "Semantic Scholar"
        elif not res:
            s2 = s2_lookup(year, title)
            time.sleep(1.1)
            if s2:
                res, source = s2, "Semantic Scholar"
        if not res or not res[3]:
            ax = arxiv_lookup(title)
            if ax:
                res, source = ax, "arXiv"
        if not res:
            notfound.append(f"{year}\tnot found\t{title}\n")
            print(f"NOT FOUND: {title}")
            continue
        t, y, first, url = res[:4]
        if url:
            found.append((f"documents/renamed/{safe_name(t)}.pdf", first, y, t, url))
            print(f"PDF ({source}): {t}")
        else:
            missing.append(f"{y}\t{first}\t{t}\n")
            print(f"PAYWALLED: {t}")

    with open(man / "manifest.tsv", "w", encoding="utf-8") as f:
        for p, a, y, t, u in found:
            f.write(f"{p}\t{a}\t{y}\t{t}\t{u}\n")
    with open(man / "missing_pdfs.tsv", "w", encoding="utf-8") as f:
        f.writelines(missing + notfound)

    print(f"\nWith free PDF: {len(found)}")
    print(f"Paywalled: {len(missing)}")
    print(f"Not found: {len(notfound)}")


if __name__ == "__main__":
    main()
